package com.crm.app.admin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrmAppAdminApplicationTests {

	@Test
	void contextLoads() {
	}

}
